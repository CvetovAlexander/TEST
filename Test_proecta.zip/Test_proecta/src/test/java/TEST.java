import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.junit.Test;
import static java.lang.Thread.sleep;
public class TEST{
    WebDriver driver;
    @Before
    public void setUp() {
        System.setProperty("webdriver.chrome.driver", "drivers\\chromedriver.exe");
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.navigate().to( "file:///C:/Users/czvet/Downloads/%D0%98%D0%BD%D0%B4%D0%B8%D0%B2%D0%B8%D0%B4%20(2)/index.html");
    }
    @After
    public void close() {
        driver.quit();
    }
                                                        //Тестирование главной страницы
//Тесты Navbar
    @Test
    public void testElementMenuGlavnay()
    {
        WebElement Glavnay = driver.findElement(By.xpath("//*[@id=\"navbarSupportedContent\"]/ul/li[1]/a"));
        Glavnay.click();
        var expectedResult = "Вас приветствует ресторан \"Clod MANE\"!";
        var actualResult = driver.findElement(By.xpath("/html/body/content/div/p[1]")).getText();
        Assert.assertEquals(expectedResult, actualResult);
    }
    @Test
    public void testElementMenuO_Nas()
    {
        WebElement O_Nas = driver.findElement(By.xpath("//*[@id=\"navbarSupportedContent\"]/ul/li[2]/a"));
        O_Nas.click();
        var expectedResult = "Познакомимся с нашими профессионалами кулинарии!!!";
        var actualResult = driver.findElement(By.xpath("/html/body/content/div/p[1]")).getText();
        Assert.assertEquals(expectedResult, actualResult);
    }
    @Test
    public void testElementMenuKyxny()
    {
        WebElement Kyxny = driver.findElement(By.xpath("//*[@id=\"navbarSupportedContent\"]/ul/li[3]/a"));
        Kyxny.click();
        var expectedResult = "\"Clod Mane\" вмещает в себя пять кухонь мира:";
        var actualResult = driver.findElement(By.xpath("/html/body/content/div/p[1]")).getText();
        Assert.assertEquals(expectedResult, actualResult);
    }
    @Test
    public void testElementMenuLogotip()
    {
        WebElement Logotip = driver.findElement(By.xpath("/html/body/nav/div/a"));
        Logotip.click();
        var expectedResult = "Вас приветствует ресторан \"Clod MANE\"!";
        var actualResult = driver.findElement(By.xpath("/html/body/content/div/p[1]")).getText();
        Assert.assertEquals(expectedResult, actualResult);
    }
    @Test
    public void testsearch()
    {
        driver.findElement(By.xpath("//*[@id=\"navbarSupportedContent\"]/form/input")).sendKeys("Итальянская кухня");
        var expectedResult = "По запросу \"Итальянская кухня\" найдено";
        var actualResult = driver.findElement(By.xpath("/html/body/content/div/p[1]")).getText();
        Assert.assertEquals(expectedResult, actualResult);
    }
//Тесты карусели
    @Test
    public void testCarusel1()
    {
        WebElement Lo = driver.findElement(By.xpath("//*[@id=\"carouselExampleIndicators\"]/div[1]/button[2]"));
        Lo.click();
        var expectedResult = driver.findElement(By.xpath("//*[@id=\"carouselExampleIndicators\"]/div[2]/div[2]/img"));
        var actualResult = driver.findElement(By.xpath("//*[@id=\"carouselExampleIndicators\"]/div[2]/div[2]/img"));
        Assert.assertEquals(expectedResult, actualResult);
    }
    @Test
    public void testCarusel2()
    {
        WebElement Lo = driver.findElement(By.xpath("//*[@id=\"carouselExampleIndicators\"]/div[1]/button[3]"));
        Lo.click();
        var expectedResult = driver.findElement(By.xpath("//*[@id=\"carouselExampleIndicators\"]/div[2]/div[3]/img"));
        var actualResult = driver.findElement(By.xpath("//*[@id=\"carouselExampleIndicators\"]/div[2]/div[3]/img"));
        Assert.assertEquals(expectedResult, actualResult);
    }
    @Test
    public void testCarusel3()
    {
        WebElement Ly = driver.findElement(By.xpath("//*[@id=\"carouselExampleIndicators\"]/div[1]/button[1]"));
        Ly.click();
        var expectedResult = driver.findElement(By.xpath("//*[@id=\"carouselExampleIndicators\"]/div[2]/div[1]/img"));
        var actualResult = driver.findElement(By.xpath("//*[@id=\"carouselExampleIndicators\"]/div[2]/div[1]/img"));
        Assert.assertEquals(expectedResult, actualResult);
    }
//Тестирование элементов под заголовком Блюдо дня
    @Test
    public void testElementJarkoe() throws InterruptedException
    {
        WebElement L = driver.findElement(By.xpath("/html/body/content/section/div/div/div[1]/div/div[2]/h4/a"));
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", L);
        sleep(1000,100);
        WebElement Ly = driver.findElement(By.xpath("/html/body/content/section/div/div/div[1]/div/div[2]/h4/a"));
        Ly.click();
        var expectedResult = "Жаркое по-деревенски";
        var actualResult = driver.findElement(By.xpath("/html/body/content/div/p[1]")).getText();
        Assert.assertEquals(expectedResult, actualResult);
    }
    @Test
    public void testElementJulien() throws InterruptedException
    {
        WebElement L = driver.findElement(By.xpath("/html/body/content/section/div/div/div[2]/div/div[2]/h4/a"));
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", L);
        sleep(1000,100);
        WebElement Ly = driver.findElement(By.xpath("/html/body/content/section/div/div/div[2]/div/div[2]/h4/a"));
        Ly.click();
        var expectedResult = "Жульен с грибами";
        var actualResult = driver.findElement(By.xpath("/html/body/content/div/p[1]")).getText();
        Assert.assertEquals(expectedResult, actualResult);
    }
    @Test
    public void testElementPasta() throws InterruptedException
    {
        WebElement L = driver.findElement(By.xpath("/html/body/content/section/div/div/div[3]/div/div[2]/h4/a"));
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", L);
        sleep(1000,100);
        WebElement Ly = driver.findElement(By.xpath("/html/body/content/section/div/div/div[3]/div/div[2]/h4/a"));
        Ly.click();
        var expectedResult = "Паста карбонара";
        var actualResult = driver.findElement(By.xpath("/html/body/content/div/p[1]")).getText();
        Assert.assertEquals(expectedResult, actualResult);
    }
//Тестирование footer
//Тесты кнопок в блоке Информация
    @Test
    public void footerGlavnya() throws InterruptedException {
        WebElement L = driver.findElement(By.xpath("/html/body/footer/section/div/div/div[1]/ul/li[1]/a"));
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", L);
        sleep(1000,100);
        driver.findElement(By.xpath("/html/body/footer/section/div/div/div[1]/ul/li[1]/a")).click();
        var expectedResult = "Вас приветствует ресторан \"Clod MANE\"!";
        var actualResult = driver.findElement(By.xpath("/html/body/content/div/p[1]")).getText();
        Assert.assertEquals(expectedResult, actualResult);
    }
    @Test
    public void footerO_Nas() throws InterruptedException {
        WebElement L = driver.findElement(By.xpath("/html/body/footer/section/div/div/div[1]/ul/li[2]/a"));
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", L);
        sleep(1000,100);
        driver.findElement(By.xpath("/html/body/footer/section/div/div/div[1]/ul/li[2]/a")).click();
        var expectedResult = "Познакомимся с нашими профессионалами кулинарии!!!";
        var actualResult = driver.findElement(By.xpath("/html/body/content/div/p[1]")).getText();
        Assert.assertEquals(expectedResult, actualResult);
    }
    @Test
    public void footerKyxny() throws InterruptedException {
        WebElement L = driver.findElement(By.xpath("/html/body/footer/section/div/div/div[1]/ul/li[3]/a"));
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", L);
        sleep(1000,100);
        driver.findElement(By.xpath("/html/body/footer/section/div/div/div[1]/ul/li[3]/a")).click();
        var expectedResult = "\"Clod Mane\" вмещает в себя пять кухонь мира:";
        var actualResult = driver.findElement(By.xpath("/html/body/content/div/p[1]")).getText();
        Assert.assertEquals(expectedResult, actualResult);
    }
    @Test
    public void footerAvtorsky_Meny() throws InterruptedException {
        WebElement L = driver.findElement(By.xpath("/html/body/footer/section/div/div/div[1]/ul/li[4]/a"));
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", L);
        sleep(1500,100);
        driver.findElement(By.xpath("/html/body/footer/section/div/div/div[1]/ul/li[4]/a")).click();
        var expectedResult = "Авторское меню";
        var actualResult = driver.findElement(By.xpath("/html/body/content/div/p[1]")).getText();
        Assert.assertEquals(expectedResult, actualResult);
    }
//Тесты иконок в блоке Мы в сети
    @Test
    public void footerOk() throws InterruptedException {
        WebElement L = driver.findElement(By.xpath("/html/body/footer/section/div/div/div[4]/div/a[2]/i"));
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", L);
        sleep(1000,100);
        driver.findElement(By.xpath("/html/body/footer/section/div/div/div[4]/div/a[2]/i")).click();
        var expectedResult = "Телефон или адрес эл. почты";
        var actualResult = driver.findElement(By.xpath("" +
                "//*[@id=\"anonymPageContent\"]/div/div[1]/div[2]/div/div[2]/div[2]/div[1]/form/div[1]/span/label" +
                "")).getText();//в другом случае когда у ресторана будет своя страница в Ок, то можно ссылка будет на название группы в Одноклассниках.
        Assert.assertEquals(expectedResult, actualResult);
    }
    @Test
    public void footerVk() throws InterruptedException {
        WebElement L = driver.findElement(By.xpath("/html/body/footer/section/div/div/div[4]/div/a[3]"));
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", L);
        sleep(1000,100);
        driver.findElement(By.xpath("/html/body/footer/section/div/div/div[4]/div/a[3]")).click();
        var expectedResult = "ВКонтакте для мобильных устройств";
        var actualResult = driver.findElement(By.xpath("" +
                "//*[@id=\"content\"]/div[1]/div[1]/div/div[1]/div[1]" +
                "")).getText();//в другом случае когда у ресторана будет своя страница в ВК, то можно ссылка будет на название группы в ВКонтакте.
        Assert.assertEquals(expectedResult, actualResult);
    }
    @Test
    public void footerViber() throws InterruptedException {
        WebElement L = driver.findElement(By.xpath("/html/body/footer/section/div/div/div[4]/div/a[1]/i"));
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", L);
        sleep(1000,100);
        driver.findElement(By.xpath("/html/body/footer/section/div/div/div[4]/div/a[1]/i")).click();
        var expectedResult = "Бесплатные и безопасные звонки и сообщения по всему миру";
        var actualResult = driver.findElement(By.xpath("" +
                "/html/body/div[1]/div/main/div[1]/div/div[1]/div/div[2]/h1" +
                "")).getText();//в другом случае когда у ресторана будет своя страница в ВК, то можно ссылка будет на название группы в ВКонтакте.
        Assert.assertEquals(expectedResult, actualResult);
    }
                                                            //Тестирование страницы О наc
//Тестирование элементов Navbar
    @Test
    public void testElementMenuGlavnaySite2()
    {
        driver.findElement(By.xpath("//*[@id=\"navbarSupportedContent\"]/ul/li[2]/a")).click();
        WebElement Glavnay = driver.findElement(By.xpath("//*[@id=\"navbarSupportedContent\"]/ul/li[1]/a"));
        Glavnay.click();
        var expectedResult = "Вас приветствует ресторан \"Clod MANE\"!";
        var actualResult = driver.findElement(By.xpath("/html/body/content/div/p[1]")).getText();
        Assert.assertEquals(expectedResult, actualResult);
    }
    @Test
    public void testElementMenuO_NasSite2()
    {
        driver.findElement(By.xpath("//*[@id=\"navbarSupportedContent\"]/ul/li[2]/a")).click();
        WebElement O_Nas = driver.findElement(By.xpath("//*[@id=\"navbarSupportedContent\"]/ul/li[2]/a"));
        O_Nas.click();
        var expectedResult = "Познакомимся с нашими профессионалами кулинарии!!!";
        var actualResult = driver.findElement(By.xpath("/html/body/content/div/p[1]")).getText();
        Assert.assertEquals(expectedResult, actualResult);
    }
    @Test
    public void testElementMenuKyxnySite2()
    {
        driver.findElement(By.xpath("//*[@id=\"navbarSupportedContent\"]/ul/li[2]/a")).click();
        WebElement Kyxny = driver.findElement(By.xpath("//*[@id=\"navbarSupportedContent\"]/ul/li[3]/a"));
        Kyxny.click();
        var expectedResult = "\"Clod Mane\" вмещает в себя пять кухонь мира:";
        var actualResult = driver.findElement(By.xpath("/html/body/content/div/p[1]")).getText();
        Assert.assertEquals(expectedResult, actualResult);
    }
    @Test
    public void testElementMenuLogotipSite2()
    {
        driver.findElement(By.xpath("//*[@id=\"navbarSupportedContent\"]/ul/li[2]/a")).click();
        WebElement Logotip = driver.findElement(By.xpath("/html/body/nav/div/a"));
        Logotip.click();
        var expectedResult = "Вас приветствует ресторан \"Clod MANE\"!";
        var actualResult = driver.findElement(By.xpath("/html/body/content/div/p[1]")).getText();
        Assert.assertEquals(expectedResult, actualResult);
    }
    @Test
    public void testsearchSite2()
    {
        driver.findElement(By.xpath("//*[@id=\"navbarSupportedContent\"]/ul/li[2]/a")).click();
        driver.findElement(By.xpath("//*[@id=\"navbarSupportedContent\"]/form/input")).sendKeys("Итальянская кухня");
        var expectedResult = "По запросу \"Итальянская кухня\" найдено";
        var actualResult = driver.findElement(By.xpath("/html/body/content/div/p[1]")).getText();
        Assert.assertEquals(expectedResult, actualResult);
    }
//Тестирование кномпок карусели
    @Test
    public void testCarusel1Site2()
    {
        WebElement Lo = driver.findElement(By.xpath("//*[@id=\"carouselExampleIndicators\"]/div[1]/button[2]"));
        Lo.click();
        var expectedResult = driver.findElement(By.xpath("//*[@id=\"carouselExampleIndicators\"]/div[2]/div[2]/img"));
        var actualResult = driver.findElement(By.xpath("//*[@id=\"carouselExampleIndicators\"]/div[2]/div[2]/img"));
        Assert.assertEquals(expectedResult, actualResult);
    }
    @Test
    public void testCarusel2Site2()
    {
        WebElement Lo = driver.findElement(By.xpath("//*[@id=\"carouselExampleIndicators\"]/div[1]/button[3]"));
        Lo.click();
        var expectedResult = driver.findElement(By.xpath("//*[@id=\"carouselExampleIndicators\"]/div[2]/div[3]/img"));
        var actualResult = driver.findElement(By.xpath("//*[@id=\"carouselExampleIndicators\"]/div[2]/div[3]/img"));
        Assert.assertEquals(expectedResult, actualResult);
    }
    @Test
    public void testCarusel3Site2()
    {
        WebElement Ly = driver.findElement(By.xpath("//*[@id=\"carouselExampleIndicators\"]/div[1]/button[1]"));
        Ly.click();
        var expectedResult = driver.findElement(By.xpath("//*[@id=\"carouselExampleIndicators\"]/div[2]/div[1]/img"));
        var actualResult = driver.findElement(By.xpath("//*[@id=\"carouselExampleIndicators\"]/div[2]/div[1]/img"));
        Assert.assertEquals(expectedResult, actualResult);
    }
//Тестирование формы Обратной связи
    @Test
    public void testFormi() throws InterruptedException {
        WebElement Lo = driver.findElement(By.xpath("//*[@id=\"navbarSupportedContent\"]/ul/li[2]/a"));
        Lo.click();
        driver.findElement(By.xpath("/html/body/content/div/label[1]/input")).sendKeys("Иванов Иван Иванович");
        driver.findElement(By.xpath("/html/body/content/div/label[2]/input")).sendKeys("cv@inbox.ru");
        driver.findElement(By.xpath("/html/body/content/div/label[3]/textarea")).sendKeys("Мне надо отправить вам документы");
        WebElement L = driver.findElement(By.xpath("/html/body/content/div/a[3]"));
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", L);
        sleep(1000,100);
        driver.findElement(By.xpath("/html/body/content/div/a[3]")).click();
        sleep(1000,100);
        driver.findElement(By.xpath("//*[@id=\"modal-opoves\"]/div/div/div[3]/a/button")).click();
        var expectedResult = "Познакомимся с нашими профессионалами кулинарии!!!";
        var actualResult = driver.findElement(By.xpath("/html/body/content/div/p[1]")).getText();
        Assert.assertEquals(expectedResult, actualResult);
    }
//Тесты footer
//Тесты кнопок в блоке Информация
    @Test
    public void footerGlavnyaSite2() throws InterruptedException {
        driver.findElement(By.xpath("//*[@id=\"navbarSupportedContent\"]/ul/li[2]/a")).click();
        WebElement L = driver.findElement(By.xpath("/html/body/footer/section/div/div/div[1]/ul/li[1]/a"));
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", L);
        sleep(1000,100);
        driver.findElement(By.xpath("/html/body/footer/section/div/div/div[1]/ul/li[1]/a")).click();
        var expectedResult = "Вас приветствует ресторан \"Clod MANE\"!";
        var actualResult = driver.findElement(By.xpath("/html/body/content/div/p[1]")).getText();
        Assert.assertEquals(expectedResult, actualResult);
    }
    @Test
    public void footerO_NasSite2() throws InterruptedException {
        driver.findElement(By.xpath("//*[@id=\"navbarSupportedContent\"]/ul/li[2]/a")).click();
        WebElement L = driver.findElement(By.xpath("/html/body/footer/section/div/div/div[1]/ul/li[2]/a"));
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", L);
        sleep(1000,100);
        driver.findElement(By.xpath("/html/body/footer/section/div/div/div[1]/ul/li[2]/a")).click();
        var expectedResult = "Познакомимся с нашими профессионалами кулинарии!!!";
        var actualResult = driver.findElement(By.xpath("/html/body/content/div/p[1]")).getText();
        Assert.assertEquals(expectedResult, actualResult);
    }
    @Test
    public void footerKyxnySite2() throws InterruptedException {
        driver.findElement(By.xpath("//*[@id=\"navbarSupportedContent\"]/ul/li[2]/a")).click();
        WebElement L = driver.findElement(By.xpath("/html/body/footer/section/div/div/div[1]/ul/li[3]/a"));
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", L);
        sleep(1000,100);
        driver.findElement(By.xpath("/html/body/footer/section/div/div/div[1]/ul/li[3]/a")).click();
        var expectedResult = "\"Clod Mane\" вмещает в себя пять кухонь мира:";
        var actualResult = driver.findElement(By.xpath("/html/body/content/div/p[1]")).getText();
        Assert.assertEquals(expectedResult, actualResult);
    }
    @Test
    public void footerAvtorsky_MenySite2() throws InterruptedException {
        driver.findElement(By.xpath("//*[@id=\"navbarSupportedContent\"]/ul/li[2]/a")).click();
        WebElement L = driver.findElement(By.xpath("/html/body/footer/section/div/div/div[1]/ul/li[4]/a"));
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", L);
        sleep(1500,100);
        driver.findElement(By.xpath("/html/body/footer/section/div/div/div[1]/ul/li[4]/a")).click();
        var expectedResult = "Авторское меню";
        var actualResult = driver.findElement(By.xpath("/html/body/content/div/p[1]")).getText();
        Assert.assertEquals(expectedResult, actualResult);
    }
//Тесты иконок в блоке Мы в сети
    @Test
    public void footerOkSite2() throws InterruptedException {
        driver.findElement(By.xpath("//*[@id=\"navbarSupportedContent\"]/ul/li[2]/a")).click();
        WebElement L = driver.findElement(By.xpath("/html/body/footer/section/div/div/div[4]/div/a[2]/i"));
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", L);
        sleep(1000,100);
        driver.findElement(By.xpath("/html/body/footer/section/div/div/div[4]/div/a[2]/i")).click();
        var expectedResult = "Телефон или адрес эл. почты";
        var actualResult = driver.findElement(By.xpath("" +
                "//*[@id=\"anonymPageContent\"]/div/div[1]/div[2]/div/div[2]/div[2]/div[1]/form/div[1]/span/label" +
                "")).getText();//в другом случае когда у ресторана будет своя страница в Ок, то можно ссылка будет на название группы в Одноклассниках.
        Assert.assertEquals(expectedResult, actualResult);
    }
    @Test
    public void footerVkSite2() throws InterruptedException {
        driver.findElement(By.xpath("//*[@id=\"navbarSupportedContent\"]/ul/li[2]/a")).click();
        WebElement L = driver.findElement(By.xpath("/html/body/footer/section/div/div/div[4]/div/a[3]"));
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", L);
        sleep(1000,100);
        driver.findElement(By.xpath("/html/body/footer/section/div/div/div[4]/div/a[3]")).click();
        var expectedResult = "ВКонтакте для мобильных устройств";
        var actualResult = driver.findElement(By.xpath("" +
                "//*[@id=\"content\"]/div[1]/div[1]/div/div[1]/div[1]" +
                "")).getText();//в другом случае когда у ресторана будет своя страница в ВК, то можно ссылка будет на название группы в ВКонтакте.
        Assert.assertEquals(expectedResult, actualResult);
    }
    @Test
    public void footerViberSite2() throws InterruptedException {
        driver.findElement(By.xpath("//*[@id=\"navbarSupportedContent\"]/ul/li[2]/a")).click();
        WebElement L = driver.findElement(By.xpath("/html/body/footer/section/div/div/div[4]/div/a[1]/i"));
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", L);
        sleep(1000,100);
        driver.findElement(By.xpath("/html/body/footer/section/div/div/div[4]/div/a[1]/i")).click();
        var expectedResult = "Бесплатные и безопасные звонки и сообщения по всему миру";
        var actualResult = driver.findElement(By.xpath("" +
                "/html/body/div[1]/div/main/div[1]/div/div[1]/div/div[2]/h1" +
                "")).getText();//в другом случае когда у ресторана будет своя страница в Viber, то можно ссылка будет на название группы в Viber.
        Assert.assertEquals(expectedResult, actualResult);
    }
                                                     //Тестирование страницы Кухня
//Тестирование элементов Navbar
    @Test
    public void testElementMenuGlavnaySite3()
    {
        driver.findElement(By.xpath("//*[@id=\"navbarSupportedContent\"]/ul/li[3]/a")).click();
        driver.findElement(By.xpath("//*[@id=\"navbarSupportedContent\"]/ul/li[2]/a")).click();
        WebElement Glavnay = driver.findElement(By.xpath("//*[@id=\"navbarSupportedContent\"]/ul/li[1]/a"));
        Glavnay.click();
        var expectedResult = "Вас приветствует ресторан \"Clod MANE\"!";
        var actualResult = driver.findElement(By.xpath("/html/body/content/div/p[1]")).getText();
        Assert.assertEquals(expectedResult, actualResult);
    }
    @Test
    public void testElementMenuO_NasSite3()
    {
        driver.findElement(By.xpath("//*[@id=\"navbarSupportedContent\"]/ul/li[3]/a")).click();
        driver.findElement(By.xpath("//*[@id=\"navbarSupportedContent\"]/ul/li[2]/a")).click();
        WebElement O_Nas = driver.findElement(By.xpath("//*[@id=\"navbarSupportedContent\"]/ul/li[2]/a"));
        O_Nas.click();
        var expectedResult = "Познакомимся с нашими профессионалами кулинарии!!!";
        var actualResult = driver.findElement(By.xpath("/html/body/content/div/p[1]")).getText();
        Assert.assertEquals(expectedResult, actualResult);
    }
    @Test
    public void testElementMenuKyxnySite3()
    {
        driver.findElement(By.xpath("//*[@id=\"navbarSupportedContent\"]/ul/li[3]/a")).click();
        driver.findElement(By.xpath("//*[@id=\"navbarSupportedContent\"]/ul/li[2]/a")).click();
        WebElement Kyxny = driver.findElement(By.xpath("//*[@id=\"navbarSupportedContent\"]/ul/li[3]/a"));
        Kyxny.click();
        var expectedResult = "\"Clod Mane\" вмещает в себя пять кухонь мира:";
        var actualResult = driver.findElement(By.xpath("/html/body/content/div/p[1]")).getText();
        Assert.assertEquals(expectedResult, actualResult);
    }
    @Test
    public void testElementMenuLogotipSite3()
    {
        driver.findElement(By.xpath("//*[@id=\"navbarSupportedContent\"]/ul/li[3]/a")).click();
        driver.findElement(By.xpath("//*[@id=\"navbarSupportedContent\"]/ul/li[2]/a")).click();
        WebElement Logotip = driver.findElement(By.xpath("/html/body/nav/div/a"));
        Logotip.click();
        var expectedResult = "Вас приветствует ресторан \"Clod MANE\"!";
        var actualResult = driver.findElement(By.xpath("/html/body/content/div/p[1]")).getText();
        Assert.assertEquals(expectedResult, actualResult);
    }
    @Test
    public void testsearchSite3()
    {
        driver.findElement(By.xpath("//*[@id=\"navbarSupportedContent\"]/ul/li[3]/a")).click();
        driver.findElement(By.xpath("//*[@id=\"navbarSupportedContent\"]/ul/li[2]/a")).click();
        driver.findElement(By.xpath("//*[@id=\"navbarSupportedContent\"]/form/input")).sendKeys("Итальянская кухня");
        var expectedResult = "По запросу \"Итальянская кухня\" найдено";
        var actualResult = driver.findElement(By.xpath("/html/body/content/div/p[1]")).getText();
        Assert.assertEquals(expectedResult, actualResult);
    }
//Тестирование кномпок карусели
    @Test
    public void testCarusel1Site3()
    {
        driver.findElement(By.xpath("//*[@id=\"navbarSupportedContent\"]/ul/li[3]/a")).click();
        WebElement Lo = driver.findElement(By.xpath("//*[@id=\"carouselExampleIndicators\"]/div[1]/button[2]"));
        Lo.click();
        var expectedResult = driver.findElement(By.xpath("//*[@id=\"carouselExampleIndicators\"]/div[2]/div[2]/img"));
        var actualResult = driver.findElement(By.xpath("//*[@id=\"carouselExampleIndicators\"]/div[2]/div[2]/img"));
        Assert.assertEquals(expectedResult, actualResult);
    }
    @Test
    public void testCarusel2Site3()
    {
        driver.findElement(By.xpath("//*[@id=\"navbarSupportedContent\"]/ul/li[3]/a")).click();
        WebElement Lo = driver.findElement(By.xpath("//*[@id=\"carouselExampleIndicators\"]/div[1]/button[3]"));
        Lo.click();
        var expectedResult = driver.findElement(By.xpath("//*[@id=\"carouselExampleIndicators\"]/div[2]/div[3]/img"));
        var actualResult = driver.findElement(By.xpath("//*[@id=\"carouselExampleIndicators\"]/div[2]/div[3]/img"));
        Assert.assertEquals(expectedResult, actualResult);
    }
    @Test
    public void testCarusel3Site3()
    {
        driver.findElement(By.xpath("//*[@id=\"navbarSupportedContent\"]/ul/li[3]/a")).click();
        WebElement Ly = driver.findElement(By.xpath("//*[@id=\"carouselExampleIndicators\"]/div[1]/button[1]"));
        Ly.click();
        var expectedResult = driver.findElement(By.xpath("//*[@id=\"carouselExampleIndicators\"]/div[2]/div[1]/img"));
        var actualResult = driver.findElement(By.xpath("//*[@id=\"carouselExampleIndicators\"]/div[2]/div[1]/img"));
        Assert.assertEquals(expectedResult, actualResult);
    }
//Тесты footer
//Тесты кнопок в блоке Информация
    @Test
    public void footerGlavnyaSite3() throws InterruptedException {
        driver.findElement(By.xpath("//*[@id=\"navbarSupportedContent\"]/ul/li[3]/a")).click();
        WebElement L = driver.findElement(By.xpath("/html/body/footer/section/div/div/div[1]/ul/li[1]/a"));
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", L);
        sleep(1000,100);
        driver.findElement(By.xpath("/html/body/footer/section/div/div/div[1]/ul/li[1]/a")).click();
        var expectedResult = "Вас приветствует ресторан \"Clod MANE\"!";
        var actualResult = driver.findElement(By.xpath("/html/body/content/div/p[1]")).getText();
        Assert.assertEquals(expectedResult, actualResult);
    }
    @Test
    public void footerO_NasSite3() throws InterruptedException {
        driver.findElement(By.xpath("//*[@id=\"navbarSupportedContent\"]/ul/li[3]/a")).click();
        WebElement L = driver.findElement(By.xpath("/html/body/footer/section/div/div/div[1]/ul/li[2]/a"));
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", L);
        sleep(1000,100);
        driver.findElement(By.xpath("/html/body/footer/section/div/div/div[1]/ul/li[2]/a")).click();
        var expectedResult = "Познакомимся с нашими профессионалами кулинарии!!!";
        var actualResult = driver.findElement(By.xpath("/html/body/content/div/p[1]")).getText();
        Assert.assertEquals(expectedResult, actualResult);
    }
    @Test
    public void footerKyxnySite3() throws InterruptedException {
        driver.findElement(By.xpath("//*[@id=\"navbarSupportedContent\"]/ul/li[3]/a")).click();
        WebElement L = driver.findElement(By.xpath("/html/body/footer/section/div/div/div[1]/ul/li[3]/a"));
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", L);
        sleep(1000,100);
        driver.findElement(By.xpath("/html/body/footer/section/div/div/div[1]/ul/li[3]/a")).click();
        var expectedResult = "\"Clod Mane\" вмещает в себя пять кухонь мира:";
        var actualResult = driver.findElement(By.xpath("/html/body/content/div/p[1]")).getText();
        Assert.assertEquals(expectedResult, actualResult);
    }
    @Test
    public void footerAvtorsky_MenySite3() throws InterruptedException {
        driver.findElement(By.xpath("//*[@id=\"navbarSupportedContent\"]/ul/li[3]/a")).click();
        WebElement L = driver.findElement(By.xpath("/html/body/footer/section/div/div/div[1]/ul/li[4]/a"));
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", L);
        sleep(1500,100);
        driver.findElement(By.xpath("/html/body/footer/section/div/div/div[1]/ul/li[4]/a")).click();
        var expectedResult = "Авторское меню";
        var actualResult = driver.findElement(By.xpath("/html/body/content/div/p[1]")).getText();
        Assert.assertEquals(expectedResult, actualResult);
    }
    //Тесты иконок в блоке Мы в сети
    @Test
    public void footerOkSite3() throws InterruptedException {
        driver.findElement(By.xpath("//*[@id=\"navbarSupportedContent\"]/ul/li[3]/a")).click();
        WebElement L = driver.findElement(By.xpath("/html/body/footer/section/div/div/div[4]/div/a[2]/i"));
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", L);
        sleep(1000,100);
        driver.findElement(By.xpath("/html/body/footer/section/div/div/div[4]/div/a[2]/i")).click();
        var expectedResult = "Телефон или адрес эл. почты";
        var actualResult = driver.findElement(By.xpath("" +
                "//*[@id=\"anonymPageContent\"]/div/div[1]/div[2]/div/div[2]/div[2]/div[1]/form/div[1]/span/label" +
                "")).getText();//в другом случае когда у ресторана будет своя страница в Ок, то можно ссылка будет на название группы в Одноклассниках.
        Assert.assertEquals(expectedResult, actualResult);
    }
    @Test
    public void footerVkSite3() throws InterruptedException {
        driver.findElement(By.xpath("//*[@id=\"navbarSupportedContent\"]/ul/li[3]/a")).click();
        WebElement L = driver.findElement(By.xpath("/html/body/footer/section/div/div/div[4]/div/a[3]"));
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", L);
        sleep(1000,100);
        driver.findElement(By.xpath("/html/body/footer/section/div/div/div[4]/div/a[3]")).click();
        var expectedResult = "ВКонтакте для мобильных устройств";
        var actualResult = driver.findElement(By.xpath("" +
                "//*[@id=\"content\"]/div[1]/div[1]/div/div[1]/div[1]" +
                "")).getText();//в другом случае когда у ресторана будет своя страница в ВК, то можно ссылка будет на название группы в ВКонтакте.
        Assert.assertEquals(expectedResult, actualResult);
    }
    @Test
    public void footerViberSite3() throws InterruptedException {
        driver.findElement(By.xpath("//*[@id=\"navbarSupportedContent\"]/ul/li[3]/a")).click();
        WebElement L = driver.findElement(By.xpath("/html/body/footer/section/div/div/div[4]/div/a[1]/i"));
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", L);
        sleep(1000,100);
        driver.findElement(By.xpath("/html/body/footer/section/div/div/div[4]/div/a[1]/i")).click();
        var expectedResult = "Бесплатные и безопасные звонки и сообщения по всему миру";
        var actualResult = driver.findElement(By.xpath("" +
                "/html/body/div[1]/div/main/div[1]/div/div[1]/div/div[2]/h1" +
                "")).getText();//в другом случае когда у ресторана будет своя страница в Viber, то можно ссылка будет на название группы в Viber.
        Assert.assertEquals(expectedResult, actualResult);
    }
}